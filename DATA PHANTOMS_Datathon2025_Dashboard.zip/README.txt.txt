===========================================
README – Dashboard Data Phantoms (Datathon)
===========================================

5.1 Software Name and Version Used
-------------------------------------------
- Software: Microsoft Power BI Desktop
- Version: 2.131 (August 2025 release) 
  
5.2 Step-by-Step Instructions to Open and Navigate the Dashboard
-------------------------------------------
1. Download and install Microsoft Power BI Desktop if not already installed.
2. Open the file named:
      "Dashboard.pbix"
3. Once opened, you will see 2 report pages at the bottom:
      - Page 1: National Overview
      - Page 2: State-level Analysis and Bed Capacity vs Cases 
4. Use the slicers (top of the pages) to filter by:
      - Date (Between)
      - State (Dropdown)
	- Year (Dropdown)

5. Navigate between pages using the tabs at the bottom of the Power BI window.
6. Hover over visuals to view tooltips and details.

5.3 Additional Requirements (Plugins or Add-ons)
-------------------------------------------
- No additional plugins or add-ons are required.
- The dashboard runs entirely within Power BI Desktop or Power BI Service.

5.4 Notes on Limitations, Assumptions, or Special Considerations
-------------------------------------------
- The "covid_cases" dataset includes both state-level and a national-level row ("Malaysia"); the state slicer excludes "Malaysia" to focus on state data but you can select all for national overview.
- Hospital beds data starts from 24 March 2020, so visuals before that date may appear blank.
- Measures such as "Bed Utilization %" depend on hospital bed data; if filters result in zero beds, the KPI card will show blank.
- The dashboard assumes consistent state naming across both datasets.
- This dashboard is intended for analytical and visualisation purposes only — not for real-time operational decision-making.

===========================================
End of README
===========================================
